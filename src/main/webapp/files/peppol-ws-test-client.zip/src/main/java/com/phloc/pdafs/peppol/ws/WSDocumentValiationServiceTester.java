package com.phloc.pdafs.peppol.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.phloc.commons.charset.CCharset;
import com.phloc.commons.io.resource.ClassPathResource;
import com.phloc.commons.io.streams.StreamUtils;
import com.phloc.peppol.ws.documentvalidationservice._20110915.ETransaction;
import com.phloc.peppol.ws.documentvalidationservice._20110915.EValidationDocumentType;
import com.phloc.peppol.ws.documentvalidationservice._20110915.EValidationSyntaxBinding;
import com.phloc.peppol.ws.documentvalidationservice._20110915.ValidationServiceResultItemType;
import com.phloc.peppol.ws.documentvalidationservice._20110915.ValidationServiceResultType;

public final class WSDocumentValiationServiceTester
{
  private static final Logger s_aLogger = LoggerFactory.getLogger (WSDocumentValiationServiceTester.class);

  public static void main (final String [] args)
  {
    s_aLogger.info ("Starting the engines");
    final String sXML = StreamUtils.getAllBytesAsString (new ClassPathResource ("invoice1.xml"), CCharset.CHARSET_UTF_8);
    final WSDocumentValidationService aService = new WSDocumentValidationService ();
    final IDocumentValidation aPort = aService.getWSDocumentValidationPort ();
    s_aLogger.info ("Starting validation process");
    final ValidationServiceResultType aResult = aPort.executeValidationPyramid (EValidationSyntaxBinding.UBL,
                                                                                EValidationDocumentType.INVOICE,
                                                                                ETransaction.T_10,
                                                                                null,
                                                                                false,
                                                                                sXML,
                                                                                "de");
    s_aLogger.info ("Return code: " + aResult.getReturnCode ());
    s_aLogger.info ("Most severe error level: " + aResult.getMostSevereErrorLevel ());
    for (final ValidationServiceResultItemType aItem : aResult.getItems ())
    {
      s_aLogger.info (aItem.getErrorLevel () +
                      " in " +
                      aItem.getValidationType () +
                      " validation on level " +
                      aItem.getValidationLevel ());
      s_aLogger.info ("  " + aItem.getErrorText ());
      s_aLogger.info ("  Location: " + aItem.getLocation ());
      if (aItem.getSVRLTest () != null)
        s_aLogger.info ("  Test: " + aItem.getSVRLTest ());
    }
    s_aLogger.info ("Done");
  }
}
